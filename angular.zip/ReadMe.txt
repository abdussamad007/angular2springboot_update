https://angular.io/guide/quickstart
http://www.concretepage.com/spring-boot/spring-boot-rest-angular-2-jpa-hibernate-mysql-crud-example
https://spring.io/guides/gs/spring-boot/