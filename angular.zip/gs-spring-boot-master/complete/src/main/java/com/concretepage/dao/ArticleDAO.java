package com.concretepage.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.concretepage.entity.Article;

@Service
public class ArticleDAO implements IArticleDAO {
	
	static Map<Integer, Article> articalDB = null;
	
	
	static{
		articalDB = new HashMap<>();
		Article art1 = new Article(123, "Cricket 360", "Sports");
		articalDB.put(123, art1);
		Article art2 = new Article(456, "Soccer 360", "Sports");
		articalDB.put(456, art2);
		Article art3 = new Article(789, "AI 360", "Computer Science");
		articalDB.put(789, art3);
		Article art4 = new Article(102, "ML 360", "Computer Science");
		articalDB.put(102, art4);
		Article art5 = new Article(103, "Physics 360", "Science");
		articalDB.put(103, art5);
		Article art6 = new Article(104, "Math 360", "Science");
		articalDB.put(104, art6);
	}
	
	//@PersistenceContext	
	//private EntityManager entityManager;	
	@Override
	public Article getArticleById(int articleId) {
		//return entityManager.find(Article.class, articleId);
		return articalDB.get(articleId);
	}
	//@SuppressWarnings("unchecked")
	@Override
	public List<Article> getAllArticles() {
		//String hql = "FROM Article as atcl ORDER BY atcl.articleId DESC";
		//return (List<Article>) entityManager.createQuery(hql).getResultList();
		
		List<Article> allArticle = new ArrayList<>();
		Collection<Article> article = articalDB.values();
		for (Article article2 : article) {
			allArticle.add(article2);
		}
		return allArticle;
	}	
	@Override
	public void createArticle(Article article) {
		//entityManager.persist(article);
		articalDB.put(article.getArticleId(), article);
		
	}
	@Override
	public void updateArticle(Article article) {
		/*Article artcl = getArticleById(article.getArticleId());
		artcl.setTitle(article.getTitle());
		artcl.setCategory(article.getCategory());
		entityManager.flush();*/
	
		Article artcl = articalDB.get(article.getArticleId());
		if(artcl!= null){
			articalDB.put(article.getArticleId(), article);
		}
		
	}
	@Override
	public void deleteArticle(int articleId) {
		articalDB.remove(articleId);
	}
	@Override
	public boolean articleExists(String title, String category) {
		/*String hql = "FROM Article as atcl WHERE atcl.title = ? and atcl.category = ?";
		int count = entityManager.createQuery(hql).setParameter(1, title)
		              .setParameter(2, category).getResultList().size();
		return count > 0 ? true : false;*/
		boolean found = false;
		Collection<Article> articles = articalDB.values();
		
		for (Article article : articles) {
			if((article.getTitle().equals(title)) && (article.getCategory().equals(category))){
				found =  true;
				break;
			}
				
			
		}
		
		return found;
		
		
	}
} 
